package model;

public class Address  {
	private int addressId;
	private String fullName;
	private String addressline1;
	private String addressline2;
	private String city;
	private String state;
	private String zip;
	private String phone;
	private int addressableId;
	private String addressableType;



	public int getAddressId() {
		return addressId;
	}
	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	
	public String getAddressline1() {
		return addressline1;
	}
	public void setAddressline1(String addressline1) {
		this.addressline1 = addressline1;
	}
	public String getAddressline2() {
		return addressline2;
	}
	public void setAddressline2(String addressline2) {
		this.addressline2 = addressline2;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getZip() {
		return zip;
	}
	public void setZip(String zip) {
		this.zip = zip;
	}
	
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	
	public int getAddressableId() {
		return addressableId;
	}
	public void setAddressableId(int addressableId) {
		this.addressableId = addressableId;
	}
	public String getAddressableType() {
		return addressableType;
	}
	public void setAddressableType(String addressableType) {
		this.addressableType = addressableType;
	}
	

}
