package model;

public class AdminUser extends User {
	

}
