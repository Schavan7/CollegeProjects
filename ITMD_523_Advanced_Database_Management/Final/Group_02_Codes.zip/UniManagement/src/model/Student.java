package model;

public class Student extends User {

}
