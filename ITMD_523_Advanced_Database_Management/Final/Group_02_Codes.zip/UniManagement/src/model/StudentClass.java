package model;


public class StudentClass {
private Integer classId;
private Integer capacity;
private Integer facultyId;
private Integer Courseid;



public Integer getClassId() {
	return classId;
}
public void setClassId(Integer classId) {
	this.classId = classId;
}

public Integer getCapacity() {
	return capacity;
}
public void setCapacity(Integer capacity) {
	this.capacity = capacity;
}
public Integer getFacultyId() {
	return facultyId;
}
public void setFacultyId(Integer facultyId) {
	this.facultyId = facultyId;
}
public Integer getCourseid() {
	return Courseid;
}
public void setCourseid(Integer claCourseid) {
	this.Courseid = claCourseid;
}

}
