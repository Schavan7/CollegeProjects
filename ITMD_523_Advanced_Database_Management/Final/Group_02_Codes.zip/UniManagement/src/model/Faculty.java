package model;

import model.dao.DepartmentDao;

public class Faculty extends User{

}
